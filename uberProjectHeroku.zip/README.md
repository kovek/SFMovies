To set up the database, run xmltosqlite.py on this directory. It will process filmLocations.csv to create xmlsqlite.db3

To get the server runnning:
$/var/www/uberProject/: . venv/bin/activate
$/var/www/uberProject/: python main.py
